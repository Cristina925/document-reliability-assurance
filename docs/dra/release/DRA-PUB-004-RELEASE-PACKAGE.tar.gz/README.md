# DRA (Document Reliability Assurance) — Release Package

**Publication edition:** DRA-PUB-004
**Scientific source:** DRA-PUB-MANUSCRIPT-1 (`docs/dra/DRA-PUB-003-MANUSCRIPT.md`, SHA-256 `5aa6cf64b3e985dca5178db6aeb1487a8103782105d968ed62625457eb8e4f8e`)
**Status:** Research-stage. No external, independent validation has yet been performed.

This is a standalone release package extracted from a larger development monorepo. It contains only the DRA-specific publication-safe surface, assembled per `docs/dra/DRA-PUBLIC-RELEASE-MANIFEST.md`; it is not the full development repository.

## Start here

- `docs/dra/DRA-RELEASE-README.md` — full DRA-specific landing page (evidence summary, reproduction instructions, repository structure, licensing).
- `docs/dra/release/DRA-PUB-004-MANUSCRIPT.pdf` and `.html` — publication-quality renderings of the manuscript.
- `docs/dra/DRA-PUB-003-MANUSCRIPT.md` — the frozen scientific manuscript itself (canonical source).
- `docs/dra/DRA-EXTERNAL-REVIEWER-ENTRY.md` — if you are reviewing this work from outside the programme, start here.
- `docs/dra/DRA-PUB-004-CHECKSUMS.sha256` — SHA-256 ledger for every canonical artefact in this package; verify with `sha256sum -c docs/dra/DRA-PUB-004-CHECKSUMS.sha256` from this directory.
- `LICENSE` — licence for DRA-authored code and documentation (MIT). See `docs/dra/DRA-ATTRIBUTION.md` for third-party material governed by separate terms (UK Open Government Licence v3.0; US federal public domain).

## What this package is not

It is not a scientifically modified successor to the frozen manuscript, and it is not evidence of external validation. See `docs/dra/DRA-PUBLIC-CLAIMS.md` for the authoritative claim-boundary register.
