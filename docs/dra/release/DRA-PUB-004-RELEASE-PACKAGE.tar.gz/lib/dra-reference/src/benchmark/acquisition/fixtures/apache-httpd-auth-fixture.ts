/**
 * DRA-ENG-010 — Production HTTP Acquisition Adapter
 * Fixture: apache-httpd-auth-fixture.ts
 *
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  LIVE ACQUISITION FIXTURE — DRA-ENG-010                                 ║
 * ║                                                                          ║
 * ║  This file was produced by a live HTTPS acquisition performed with      ║
 * ║  createHttpFetcher() (DRA-ENG-010) on 2026-08-03T15:05:12.059Z.        ║
 * ║                                                                          ║
 * ║  The HTML content below is the verbatim response body received from     ║
 * ║  the official Apache HTTP Server documentation server. The pre-computed ║
 * ║  SHA-256 digests are computed from those exact bytes.                   ║
 * ║                                                                          ║
 * ║  To verify authenticity, compare the content against the official       ║
 * ║  source listed in officialSourceUrl below.                               ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *
 * Document: Apache HTTP Server 2.4 — Authentication and Authorization How-To
 * Publisher: The Apache Software Foundation
 * Official source URL:
 *   https://httpd.apache.org/docs/2.4/howto/auth.html
 * Licence: Apache License, Version 2.0
 *   https://www.apache.org/licenses/LICENSE-2.0
 * Licence basis: OPEN_LICENCE — permissive, attribution required
 * Live acquisition date: 2026-08-03
 * Last-Modified (at acquisition): Fri, 19 Jun 2026 14:27:30 GMT
 *
 * Corpus document ID: DRA-DOC-0007
 * Acquisition request ID: DRA-ACQ-000001
 */

// ---------------------------------------------------------------------------
// Verbatim HTML — exact bytes as received from httpd.apache.org
// ---------------------------------------------------------------------------

/**
 * Verbatim HTML of the Apache HTTP Server 2.4 Authentication and
 * Authorization how-to guide, as received on 2026-08-03.
 *
 * This is the complete, unmodified HTTP response body (36,023 bytes).
 * The source SHA-256 digest is pre-computed and stored below.
 */
export const APACHE_HTTPD_AUTH_HTML: string = `<!DOCTYPE html SYSTEM "about:legacy-compat">
<html lang="en"><head><META http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="width=device-width, initial-scale=1" name="viewport">
<!--
        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
              This file is generated from xml source: DO NOT EDIT
        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
      -->
<title>Authentication and Authorization - Apache HTTP Server Version 2.4</title>
<link href="../style/css/manual.css" rel="stylesheet" media="all" type="text/css" title="Main stylesheet">
<link href="../style/css/manual-loose-100pc.css" rel="alternate stylesheet" media="all" type="text/css" title="No Sidebar - Default font size">
<link href="../style/css/manual-print.css" rel="stylesheet" media="print" type="text/css"><link rel="stylesheet" type="text/css" href="../style/css/prettify.css">
<script src="../style/scripts/prettify.min.js">
</script>

<link href="../images/favicon.png" rel="shortcut icon"></head>
<body id="manual-page"><div id="page-header">
<p class="menu"><a href="../mod/">Modules</a> | <a href="../mod/quickreference.html">Directives</a> | <a href="https://cwiki.apache.org/confluence/display/httpd/FAQ">FAQ</a> | <a href="../glossary.html">Glossary</a> | <a href="../sitemap.html">Sitemap</a> | <a href="https://bz.apache.org/bugzilla/enter_bug.cgi?product=Apache%20httpd-2">Report a bug</a></p>
<p class="apache">Apache HTTP Server Version 2.4</p>
<img alt="" src="../images/feather.png"></div>
<div class="up"><a href="./"><img title="<-" alt="<-" src="../images/left.gif"></a></div>
<div id="path">
<a href="https://www.apache.org/">Apache</a> &gt; <a href="https://httpd.apache.org/">HTTP Server</a> &gt; <a href="https://httpd.apache.org/docs/">Documentation</a> &gt; <a href="../">Version 2.4</a> &gt; <a href="./">How-To / Tutorials</a></div><div id="page-content"><div id="preamble"><h1>Authentication and Authorization</h1>
<button aria-label="Toggle language list" class="lang-toggle"><svg xmlns="http://www.w3.org/2000/svg" stroke-width="2" stroke="currentColor" fill="none" viewBox="0 0 24 24" height="16" width="16"><circle r="10" cy="12" cx="12"/><line y2="12" x2="22" y1="12" x1="2"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></button>
<div class="toplang">
<p><span>Available Languages: </span><a href="../en/howto/auth.html" title="English">&nbsp;en&nbsp;</a> |
<a href="../es/howto/auth.html" hreflang="es" rel="alternate" title="Espa&ntilde;ol">&nbsp;es&nbsp;</a> |
<a href="../fr/howto/auth.html" hreflang="fr" rel="alternate" title="Fran&ccedil;ais">&nbsp;fr&nbsp;</a> |
<a href="../ja/howto/auth.html" hreflang="ja" rel="alternate" title="Japanese">&nbsp;ja&nbsp;</a> |
<a href="../ko/howto/auth.html" hreflang="ko" rel="alternate" title="Korean">&nbsp;ko&nbsp;</a> |
<a href="../tr/howto/auth.html" hreflang="tr" rel="alternate" title="T&uuml;rk&ccedil;e">&nbsp;tr&nbsp;</a></p>
</div>

    <p>Authentication is any process by which you verify that
    someone is who they claim they are. Authorization is any
    process by which someone is allowed to be where they want to
    go, or to have information that they want to have.</p>

    <p>For general access control, see the <a href="access.html">Access
    Control How-To</a>.</p>
</div>
<div id="quickview"><ul id="toc"><li><img alt="" src="../images/down.gif"> <a href="#related">Related Modules and Directives</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#introduction">Introduction</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#theprerequisites">The Prerequisites</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#gettingitworking">Getting it working</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#lettingmorethanonepersonin">Letting more than one
person in</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#possibleproblems">Possible problems</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#dbmdbd">Alternate password storage</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#multprovider">Using multiple providers</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#beyond">Beyond just authorization</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#socache">Authentication Caching</a></li>
<li><img alt="" src="../images/down.gif"> <a href="#moreinformation">More information</a></li>
</ul></div>
<div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="related">Related Modules and Directives <a title="Permanent link" href="#related" class="permalink">&para;</a></h2>

<p>There are three types of modules involved in the authentication and
authorization process.  You will usually need to choose at least one
module from each group.</p>

<ul>
  <li>Authentication type (see the
      <code class="directive"><a href="../mod/mod_authn_core.html#authtype">AuthType</a></code> directive)
    <ul>
      <li><code class="module"><a href="../mod/mod_auth_basic.html">mod_auth_basic</a></code></li>
      <li><code class="module"><a href="../mod/mod_auth_digest.html">mod_auth_digest</a></code></li>
    </ul>
  </li>
  <li>Authentication provider (see the
  <code class="directive"><a href="../mod/mod_auth_basic.html#authbasicprovider">AuthBasicProvider</a></code> and
  <code class="directive"><a href="../mod/mod_auth_digest.html#authdigestprovider">AuthDigestProvider</a></code> directives)

    <ul>
      <li><code class="module"><a href="../mod/mod_authn_anon.html">mod_authn_anon</a></code></li>
      <li><code class="module"><a href="../mod/mod_authn_dbd.html">mod_authn_dbd</a></code></li>
      <li><code class="module"><a href="../mod/mod_authn_dbm.html">mod_authn_dbm</a></code></li>
      <li><code class="module"><a href="../mod/mod_authn_file.html">mod_authn_file</a></code></li>
      <li><code class="module"><a href="../mod/mod_authnz_ldap.html">mod_authnz_ldap</a></code></li>
      <li><code class="module"><a href="../mod/mod_authn_socache.html">mod_authn_socache</a></code></li>
    </ul>
  </li>
  <li>Authorization (see the
      <code class="directive"><a href="../mod/mod_authz_core.html#require">Require</a></code> directive)
    <ul>
      <li><code class="module"><a href="../mod/mod_authnz_ldap.html">mod_authnz_ldap</a></code></li>
      <li><code class="module"><a href="../mod/mod_authz_dbd.html">mod_authz_dbd</a></code></li>
      <li><code class="module"><a href="../mod/mod_authz_dbm.html">mod_authz_dbm</a></code></li>
      <li><code class="module"><a href="../mod/mod_authz_groupfile.html">mod_authz_groupfile</a></code></li>
      <li><code class="module"><a href="../mod/mod_authz_host.html">mod_authz_host</a></code></li>
      <li><code class="module"><a href="../mod/mod_authz_owner.html">mod_authz_owner</a></code></li>
      <li><code class="module"><a href="../mod/mod_authz_user.html">mod_authz_user</a></code></li>
    </ul>
  </li>
</ul>

  <p>In addition to these modules, there are also
  <code class="module"><a href="../mod/mod_authn_core.html">mod_authn_core</a></code> and
  <code class="module"><a href="../mod/mod_authz_core.html">mod_authz_core</a></code>.  These modules implement core
  directives that are core to all auth modules.</p>

  <p>The module <code class="module"><a href="../mod/mod_authnz_ldap.html">mod_authnz_ldap</a></code> is both an
  authentication and authorization provider.  The module
  <code class="module"><a href="../mod/mod_authz_host.html">mod_authz_host</a></code> provides authorization
  and access control based on hostname, IP address or characteristics
  of the request, but is not part of the authentication provider
  system. For backwards compatibility with the mod_access, there is
  a new module <code class="module"><a href="../mod/mod_access_compat.html">mod_access_compat</a></code>.</p>

  <p>You probably also want to take a look at the <a href="access.html">Access Control</a> howto, which discusses the
  various ways to control access to your server.</p>

</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="introduction">Introduction <a title="Permanent link" href="#introduction" class="permalink">&para;</a></h2>
    <p>If you have information on your web site that is sensitive
    or intended for only a small group of people, the techniques in
    this article will help you make sure that the people that see
    those pages are the people that you wanted to see them.</p>

    <p>This article covers the "standard" way of protecting parts
    of your web site that most of you are going to use.</p>

    <div class="note"><h3>Note:</h3>
    <p>If your data really needs to be secure, consider using
    <code class="module"><a href="../mod/mod_ssl.html">mod_ssl</a></code> in addition to any authentication.</p>
    </div>
</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="theprerequisites">The Prerequisites <a title="Permanent link" href="#theprerequisites" class="permalink">&para;</a></h2>
    <p>The directives discussed in this article will need to go
    either in your main server configuration file (typically in a
    <code class="directive"><a href="../mod/core.html#directory">&lt;Directory&gt;</a></code> section), or
    in per-directory configuration files (<code>.htaccess</code> files).</p>

    <p>If you plan to use <code>.htaccess</code> files, you will
    need to have a server configuration that permits putting
    authentication directives in these files. This is done with the
    <code class="directive"><a href="../mod/core.html#allowoverride">AllowOverride</a></code> directive, which
    specifies which directives, if any, may be put in per-directory
    configuration files.</p>

    <p>Since we're talking here about authentication, you will need
    an <code class="directive"><a href="../mod/core.html#allowoverride">AllowOverride</a></code> directive like the
    following:</p>

<div class="example"><pre class="prettyprint lang-config">AllowOverride AuthConfig</pre>
</div>

    <p>Or, if you are just going to put the directives directly in
    your main server configuration file, you will of course need to
    have write permission to that file.</p>

    <p>And you'll need to know a little bit about the directory
    structure of your server, in order to know where some files are
    kept. This should not be terribly difficult, and I'll try to
    make this clear when we come to that point.</p>

    <p>You will also need to make sure that the modules
    <code class="module"><a href="../mod/mod_authn_core.html">mod_authn_core</a></code> and <code class="module"><a href="../mod/mod_authz_core.html">mod_authz_core</a></code>
    have either been built into the httpd binary or loaded by the
    httpd.conf configuration file. Both of these modules provide core
    directives and functionality that are critical to the configuration
    and use of authentication and authorization in the web server.</p>
</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="gettingitworking">Getting it working <a title="Permanent link" href="#gettingitworking" class="permalink">&para;</a></h2>
    <p>Here's the basics of password protecting a directory on your
    server.</p>

    <p>First, you need to create a password file. Exactly how you do
    this will vary depending on what authentication provider you have
    chosen. More on that later. To start with, we'll use a text password
    file.</p>

    <p>This file should be
    placed somewhere not accessible from the web. This is so that
    folks cannot download the password file. For example, if your
    documents are served out of <code>/usr/local/apache/htdocs</code>, you
    might want to put the password file(s) in
    <code>/usr/local/apache/passwd</code>.</p>

    <p>To create the file, use the <code class="program"><a href="../programs/htpasswd.html">htpasswd</a></code> utility that
    came with Apache. This will be located in the <code>bin</code> directory
    of wherever you installed Apache. If you have installed Apache from
    a third-party package, it may be in your execution path.</p>

    <p>To create the file, type:</p>

    <div class="example"><p><code>
      htpasswd -c /usr/local/apache/passwd/passwords rbowen
    </code></p></div>

    <p><code class="program"><a href="../programs/htpasswd.html">htpasswd</a></code> will ask you for the password, and
    then ask you to type it again to confirm it:</p>

    <div class="example"><p><code>
      # htpasswd -c /usr/local/apache/passwd/passwords rbowen<br>
      New password: mypassword<br>
      Re-type new password: mypassword<br>
      Adding password for user rbowen
    </code></p></div>

    <p>If <code class="program"><a href="../programs/htpasswd.html">htpasswd</a></code> is not in your path, of course
    you'll have to type the full path to the file to get it to run.
    With a default installation, it's located at
    <code>/usr/local/apache2/bin/htpasswd</code></p>

    <p>Next, you'll need to configure the server to request a
    password and tell the server which users are allowed access.
    You can do this either by editing the <code>httpd.conf</code>
    file or using an <code>.htaccess</code> file. For example, if
    you wish to protect the directory
    <code>/usr/local/apache/htdocs/secret</code>, you can use the
    following directives, either placed in the file
    <code>/usr/local/apache/htdocs/secret/.htaccess</code>, or
    placed in <code>httpd.conf</code> inside a &lt;Directory
    "/usr/local/apache/htdocs/secret"&gt; section.</p>

<div class="example"><pre class="prettyprint lang-config">AuthType Basic
AuthName "Restricted Files"
# (Following line optional)
AuthBasicProvider file
AuthUserFile "/usr/local/apache/passwd/passwords"
Require user rbowen</pre>
</div>

    <p>Let's examine each of those directives individually. The <code class="directive"><a href="../mod/mod_authn_core.html#authtype">AuthType</a></code> directive selects
    the method that is used to authenticate the user. The most
    common method is <code>Basic</code>, and this is the method
    implemented by <code class="module"><a href="../mod/mod_auth_basic.html">mod_auth_basic</a></code>. It is important to be aware,
    however, that Basic authentication sends the password from the client to
    the server unencrypted. This method should therefore not be used for
    highly sensitive data, unless accompanied by <code class="module"><a href="../mod/mod_ssl.html">mod_ssl</a></code>.
    Apache supports one other authentication method:
    <code>AuthType Digest</code>. This method is implemented by <code class="module"><a href="../mod/mod_auth_digest.html">mod_auth_digest</a></code> and was intended to be more secure. This is no
    longer the case and the connection should be encrypted with <code class="module"><a href="../mod/mod_ssl.html">mod_ssl</a></code> instead.</p>

    <p>The <code class="directive"><a href="../mod/mod_authn_core.html#authname">AuthName</a></code> directive sets
    the <dfn>Realm</dfn> to be used in the authentication. The realm serves
    two major functions. First, the client often presents this information to
    the user as part of the password dialog box. Second, it is used by the
    client to determine what password to send for a given authenticated
    area.</p>

    <p>So, for example, once a client has authenticated in the
    <code>"Restricted Files"</code> area, it will automatically
    retry the same password for any area on the same server that is
    marked with the <code>"Restricted Files"</code> Realm.
    Therefore, you can prevent a user from being prompted more than
    once for a password by letting multiple restricted areas share
    the same realm. Of course, for security reasons, the client
    will always need to ask again for the password whenever the
    hostname of the server changes.</p>

    <p>The <code class="directive"><a href="../mod/mod_auth_basic.html#authbasicprovider">AuthBasicProvider</a></code> is,
    in this case, optional, since <code>file</code> is the default value
    for this directive. You'll need to use this directive if you are
    choosing a different source for authentication, such as
    <code class="module"><a href="../mod/mod_authn_dbm.html">mod_authn_dbm</a></code> or <code class="module"><a href="../mod/mod_authn_dbd.html">mod_authn_dbd</a></code>.</p>

    <p>The <code class="directive"><a href="../mod/mod_authn_file.html#authuserfile">AuthUserFile</a></code>
    directive sets the path to the password file that we just
    created with <code class="program"><a href="../programs/htpasswd.html">htpasswd</a></code>. If you have a large number
    of users, it can be quite slow to search through a plain text
    file to authenticate the user on each request. Apache also has
    the ability to store user information in fast database files.
    The <code class="module"><a href="../mod/mod_authn_dbm.html">mod_authn_dbm</a></code> module provides the <code class="directive"><a href="../mod/mod_authn_dbm.html#authdbmuserfile">AuthDBMUserFile</a></code> directive. These
    files can be created and manipulated with the <code class="program"><a href="../programs/dbmmanage.html">dbmmanage</a></code> and <code class="program"><a href="../programs/htdbm.html">htdbm</a></code> programs. Many
    other types of authentication options are available from third
    party modules.</p>

    <p>Finally, the <code class="directive"><a href="../mod/mod_authz_core.html#require">Require</a></code>
    directive provides the authorization part of the process by
    setting the user that is allowed to access this region of the
    server. In the next section, we discuss various ways to use the
    <code class="directive"><a href="../mod/mod_authz_core.html#require">Require</a></code> directive.</p>
</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="lettingmorethanonepersonin">Letting more than one
person in <a title="Permanent link" href="#lettingmorethanonepersonin" class="permalink">&para;</a></h2>
    <p>The directives above only let one person (specifically
    someone with a username of <code>rbowen</code>) into the
    directory. In most cases, you'll want to let more than one
    person in. This is where the <code class="directive"><a href="../mod/mod_authz_groupfile.html#authgroupfile">AuthGroupFile</a></code> comes in.</p>

    <p>If you want to let more than one person in, you'll need to
    create a group file that associates group names with a list of
    users in that group. The format of this file is pretty simple,
    and you can create it with your favorite editor. The contents
    of the file will look like this:</p>

   <div class="example"><p><code>
     GroupName: rbowen dpitts sungo rshersey
   </code></p></div>

    <p>That's just a list of the members of the group in a long
    line separated by spaces.</p>

    <p>To add a user to your already existing password file,
    type:</p>

    <div class="example"><p><code>
      htpasswd /usr/local/apache/passwd/passwords dpitts
    </code></p></div>

    <p>You'll get the same response as before, but it will be
    appended to the existing file, rather than creating a new file.
    (It's the <code>-c</code> that makes it create a new password
    file).</p>

    <p>Now, you need to modify your <code>.htaccess</code> file to
    look like the following:</p>

<div class="example"><pre class="prettyprint lang-config">AuthType Basic
AuthName "By Invitation Only"
# Optional line:
AuthBasicProvider file
AuthUserFile "/usr/local/apache/passwd/passwords"
AuthGroupFile "/usr/local/apache/passwd/groups"
Require group GroupName</pre>
</div>

    <p>Now, anyone that is listed in the group <code>GroupName</code>,
    and has an entry in the <code>password</code> file, will be let in, if
    they type the correct password.</p>

    <p>There's another way to let multiple users in that is less
    specific. Rather than creating a group file, you can just use
    the following directive:</p>

<div class="example"><pre class="prettyprint lang-config">Require valid-user</pre>
</div>

    <p>Using that rather than the <code>Require user rbowen</code>
    line will allow anyone in that is listed in the password file,
    and who correctly enters their password. You can even emulate
    the group behavior here, by just keeping a separate password
    file for each group. The advantage of this approach is that
    Apache only has to check one file, rather than two. The
    disadvantage is that you have to maintain a bunch of password
    files, and remember to reference the right one in the
    <code class="directive"><a href="../mod/mod_authn_file.html#authuserfile">AuthUserFile</a></code> directive.</p>
</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="possibleproblems">Possible problems <a title="Permanent link" href="#possibleproblems" class="permalink">&para;</a></h2>
    <p>Because of the way that Basic authentication is specified,
    your username and password must be verified every time you
    request a document from the server. This is even if you're
    reloading the same page, and for every image on the page (if
    they come from a protected directory). As you can imagine, this
    slows things down a little. The amount that it slows things
    down is proportional to the size of the password file, because
    it has to open up that file, and go down the list of users
    until it gets to your name. And it has to do this every time a
    page is loaded.</p>

    <p>A consequence of this is that there's a practical limit to
    how many users you can put in one password file. This limit
    will vary depending on the performance of your particular
    server machine, but you can expect to see slowdowns once you
    get above a few hundred entries, and may wish to consider a
    different authentication method at that time.</p>
</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="dbmdbd">Alternate password storage <a title="Permanent link" href="#dbmdbd" class="permalink">&para;</a></h2>

    <p>Because storing passwords in plain text files has the above
    problems, you may wish to store your passwords somewhere else, such
    as in a database.</p>

    <p><code class="module"><a href="../mod/mod_authn_dbm.html">mod_authn_dbm</a></code> and <code class="module"><a href="../mod/mod_authn_dbd.html">mod_authn_dbd</a></code> are two
    modules which make this possible. Rather than selecting <code><code class="directive"><a href="../mod/mod_auth_basic.html#authbasicprovider">AuthBasicProvider</a></code> file</code>, instead
    you can choose <code>dbm</code> or <code>dbd</code> as your storage
    format.</p>

    <p>To select a dbm file rather than a text file, for example:</p>

<div class="example"><pre class="prettyprint lang-config">&lt;Directory "/www/docs/private"&gt;
AuthName "Private"
AuthType Basic
AuthBasicProvider dbm
AuthDBMUserFile "/www/passwords/passwd.dbm"
Require valid-user
&lt;/Directory&gt;</pre>
</div>

    <p>Other options are available. Consult the
    <code class="module"><a href="../mod/mod_authn_dbm.html">mod_authn_dbm</a></code> documentation for more details.</p>
</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="multprovider">Using multiple providers <a title="Permanent link" href="#multprovider" class="permalink">&para;</a></h2>

    <p>With the introduction of the new provider based authentication and
    authorization architecture, you are no longer locked into a single
    authentication or authorization method. In fact any number of the
    providers can be mixed and matched to provide you with exactly the
    scheme that meets your needs. In the following example, both the
    file and LDAP based authentication providers are being used.</p>

<div class="example"><pre class="prettyprint lang-config">&lt;Directory "/www/docs/private"&gt;
AuthName "Private"
AuthType Basic
AuthBasicProvider file ldap
AuthUserFile "/usr/local/apache/passwd/passwords"
AuthLDAPURL ldap://ldaphost/o=yourorg
Require valid-user
&lt;/Directory&gt;</pre>
</div>

    <p>In this example the file provider will attempt to authenticate
    the user first. If it is unable to authenticate the user, the LDAP
    provider will be called. This allows the scope of authentication
    to be broadened if your organization implements more than
    one type of authentication store. Other authentication and authorization
    scenarios may include mixing one type of authentication with a
    different type of authorization. For example, authenticating against
    a password file yet authorizing against an LDAP directory.</p>

    <p>Just as multiple authentication providers can be implemented, multiple
    authorization methods can also be used. In this example both file group
    authorization as well as LDAP group authorization is being used.</p>

<div class="example"><pre class="prettyprint lang-config">&lt;Directory "/www/docs/private"&gt;
AuthName "Private"
AuthType Basic
AuthBasicProvider file
AuthUserFile "/usr/local/apache/passwd/passwords"
AuthLDAPURL ldap://ldaphost/o=yourorg
AuthGroupFile "/usr/local/apache/passwd/groups"
Require group GroupName
Require ldap-group cn=mygroup,o=yourorg
&lt;/Directory&gt;</pre>
</div>

    <p>To take authorization a little further, authorization container
    directives such as
    <code class="directive"><a href="../mod/mod_authz_core.html#requireall">&lt;RequireAll&gt;</a></code>
    and
    <code class="directive"><a href="../mod/mod_authz_core.html#requireany">&lt;RequireAny&gt;</a></code>
    allow logic to be applied so that the order in which authorization
    is handled can be completely controlled through the configuration.
    See <a href="../mod/mod_authz_core.html#logic">Authorization
    Containers</a> for an example of how they may be applied.</p>

</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="beyond">Beyond just authorization <a title="Permanent link" href="#beyond" class="permalink">&para;</a></h2>

    <p>The way that authorization can be applied is now much more flexible
    than just a single check against a single data store. Ordering, logic
    and choosing how authorization will be done is now possible.</p>

    <h3 id="authandororder">Applying logic and ordering</h3>
        <p>Controlling how and in what order authorization will be applied
        has been a bit of a mystery in the past. In Apache 2.2 a provider-based
        authentication mechanism was introduced to decouple the actual
        authentication process from authorization and supporting functionality.
        One of the side benefits was that authentication providers could be
        configured and called in a specific order which didn't depend on the
        load order of the auth module itself. This same provider based mechanism
        has been brought forward into authorization as well. What this means is
        that the <code class="directive"><a href="../mod/mod_authz_core.html#require">Require</a></code> directive
        not only specifies which authorization methods should be used, it also
        specifies the order in which they are called. Multiple authorization
        methods are called in the same order in which the
        <code class="directive"><a href="../mod/mod_authz_core.html#require">Require</a></code> directives
        appear in the configuration.</p>

        <p>With the introduction of authorization container directives
        such as
        <code class="directive"><a href="../mod/mod_authz_core.html#requireall">&lt;RequireAll&gt;</a></code>
        and
        <code class="directive"><a href="../mod/mod_authz_core.html#requireany">&lt;RequireAny&gt;</a></code>,
        the configuration also has control over when the
        authorization methods are called and what criteria determines when
        access is granted.  See
        <a href="../mod/mod_authz_core.html#logic">Authorization Containers</a>
        for an example of how they may be used to express complex
        authorization logic.  Each authorization provider returns one
        of three possible results; see
        <a href="../mod/mod_authz_core.html#authzresults">Authorization Result States</a>
        for details on how containers interpret these results.</p>

        <p>By default all
        <code class="directive"><a href="../mod/mod_authz_core.html#require">Require</a></code>
        directives are handled as though contained within a
        <code class="directive"><a href="../mod/mod_authz_core.html#requireany">&lt;RequireAny&gt;</a></code>
        container directive.  In other words, if
        any of the specified authorization methods succeed, then authorization
        is granted.</p>

    

    <h3 id="reqaccessctrl">Using authorization providers for access control</h3>
        <p>Authentication by username and password is only part of the
        story. You can also allow or deny access based on other
        criteria, such as the client's IP address or hostname, using
        the authorization providers <code>all</code>, <code>env</code>,
        <code>host</code>, and <code>ip</code> with the
        <code class="directive"><a href="../mod/mod_authz_core.html#require">Require</a></code>
        directive.</p>

        <p>For full details and examples, see the
        <a href="access.html">Access Control</a> howto.</p>
    

    <h3 id="filesystem">Access Control backwards compatibility</h3>
        <p>One of the side effects of adopting a provider based mechanism for
        authorization is that the previous access control directives
        <code class="directive"><a href="../mod/mod_access_compat.html#order">Order</a></code>,
        <code class="directive"><a href="../mod/mod_access_compat.html#allow">Allow</a></code>,
        <code class="directive"><a href="../mod/mod_access_compat.html#deny">Deny</a></code> and
        <code class="directive"><a href="../mod/mod_access_compat.html#satisfy">Satisfy</a></code> are no longer needed.
        However to provide backwards compatibility for older configurations, these
        directives have been moved to the <code class="module"><a href="../mod/mod_access_compat.html">mod_access_compat</a></code> module.</p>

        <div class="warning"><h3>Note</h3>
        <p>The directives provided by <code class="module"><a href="../mod/mod_access_compat.html">mod_access_compat</a></code> have
        been deprecated by <code class="module"><a href="../mod/mod_authz_host.html">mod_authz_host</a></code>.
        Mixing old directives like <code class="directive"><a href="../mod/mod_access_compat.html#order">Order</a></code>, <code class="directive"><a href="../mod/mod_access_compat.html#allow">Allow</a></code> or <code class="directive"><a href="../mod/mod_access_compat.html#deny">Deny</a></code> with new ones like
        <code class="directive"><a href="../mod/mod_authz_core.html#require">Require</a></code> is technically possible
        but discouraged. The <code class="module"><a href="../mod/mod_access_compat.html">mod_access_compat</a></code> module was created to support
        configurations containing only old directives to facilitate the 2.4 upgrade.
        Please check the <a href="../upgrading.html">upgrading</a> guide for more
        information.
        </p>
        </div>
    

</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="socache">Authentication Caching <a title="Permanent link" href="#socache" class="permalink">&para;</a></h2>
    <p>There may be times when authentication puts an unacceptable load
    on a provider or on your network.  This is most likely to affect users
    of <code class="module"><a href="../mod/mod_authn_dbd.html">mod_authn_dbd</a></code> (or third-party/custom providers).  The
    <code class="module"><a href="../mod/mod_authn_socache.html">mod_authn_socache</a></code> module caches credentials and reduces
    the load on the origin provider(s).</p>
    <p>This may offer a substantial performance boost to some users.</p>
</div><div class="top"><a href="#page-header"><img alt="top" src="../images/up.gif"></a></div>
<div class="section">
<h2 id="moreinformation">More information <a title="Permanent link" href="#moreinformation" class="permalink">&para;</a></h2>
    <p>You should also read the documentation for
    <code class="module"><a href="../mod/mod_auth_basic.html">mod_auth_basic</a></code> and <code class="module"><a href="../mod/mod_authz_host.html">mod_authz_host</a></code>
    which contain some more information about how this all works.  The
    directive <code class="directive"><a href="../mod/mod_authn_core.html#authnprovideralias">&lt;AuthnProviderAlias&gt;</a></code> can also help
    in simplifying certain authentication configurations.</p>

    <p>The various ciphers supported by Apache for authentication data are
    explained in <a href="../misc/password_encryptions.html">Password
    Encryptions</a>.</p>

    <p>And you may want to look at the <a href="access.html">Access
    Control</a> howto, which discusses a number of related topics.</p>

</div></div>
<div class="bottomlang">
<p><span>Available Languages: </span><a href="../en/howto/auth.html" title="English">&nbsp;en&nbsp;</a> |
<a href="../es/howto/auth.html" hreflang="es" rel="alternate" title="Espa&ntilde;ol">&nbsp;es&nbsp;</a> |
<a href="../fr/howto/auth.html" hreflang="fr" rel="alternate" title="Fran&ccedil;ais">&nbsp;fr&nbsp;</a> |
<a href="../ja/howto/auth.html" hreflang="ja" rel="alternate" title="Japanese">&nbsp;ja&nbsp;</a> |
<a href="../ko/howto/auth.html" hreflang="ko" rel="alternate" title="Korean">&nbsp;ko&nbsp;</a> |
<a href="../tr/howto/auth.html" hreflang="tr" rel="alternate" title="T&uuml;rk&ccedil;e">&nbsp;tr&nbsp;</a></p>
</div><div id="footer">
<p class="apache">Copyright 2026 The Apache Software Foundation.<br>Licensed under the <a href="https://www.apache.org/licenses/LICENSE-2.0">Apache License, Version 2.0</a>.</p>
<p class="menu"><a href="../mod/">Modules</a> | <a href="../mod/quickreference.html">Directives</a> | <a href="https://cwiki.apache.org/confluence/display/httpd/FAQ">FAQ</a> | <a href="../glossary.html">Glossary</a> | <a href="../sitemap.html">Sitemap</a> | <a href="https://bz.apache.org/bugzilla/enter_bug.cgi?product=Apache%20httpd-2">Report a bug</a></p></div><script><!--//--><![CDATA[//><!--
if (typeof(prettyPrint) !== 'undefined') {
    prettyPrint();
}
var langToggle = document.querySelector('.lang-toggle');
var topLang = document.querySelector('.toplang');
if (langToggle && topLang) {
    langToggle.addEventListener('click', function() { topLang.classList.toggle('open'); });
}
var qv = document.getElementById('quickview');
if (qv) {
    document.body.appendChild(qv);
    var qvBtn = document.createElement('button');
    qvBtn.className = 'qv-toggle';
    qvBtn.setAttribute('aria-label', 'Toggle page navigation');
    qvBtn.innerHTML = '&#9776;';
    document.body.appendChild(qvBtn);
    qvBtn.addEventListener('click', function() {
        var isOpen = qv.classList.toggle('open');
        if (isOpen) {
            qv.style.top = window.scrollY + 10 + 'px';
        }
    });
    window.addEventListener('scroll', function() { qv.classList.remove('open'); });
}
//--><!]]></script>
</body></html>`;

// ---------------------------------------------------------------------------
// Fixture metadata
// ---------------------------------------------------------------------------

export const APACHE_HTTPD_AUTH_FIXTURE = Object.freeze({
  fixtureLabel:
    "LIVE ACQUISITION FIXTURE — DRA-ENG-010 (fetched 2026-08-03)" as const,

  acquisitionId: "DRA-ACQ-000001" as const,
  corpusDocumentId: "DRA-DOC-0007" as const,

  officialSourceUrl:
    "https://httpd.apache.org/docs/2.4/howto/auth.html" as const,

  finalUrl:
    "https://httpd.apache.org/docs/2.4/howto/auth.html" as const,

  publisher: "The Apache Software Foundation" as const,
  licenceBasis: "OPEN_LICENCE" as const,
  licenceStatement:
    "Apache License, Version 2.0 — https://www.apache.org/licenses/LICENSE-2.0" as const,

  liveAcquisitionDate: "2026-08-03" as const,
  retrievedAt: "2026-08-03T15:05:12.059Z" as const,

  httpStatus: 200,
  mediaType: "text/html" as const,
  rawByteLength: 36023,
  wordCount: 3429,

  httpResponseHeaders: Object.freeze({
    contentType: "text/html" as const,
    contentLength: "36023" as const,
    lastModified: "Fri, 19 Jun 2026 14:27:30 GMT" as const,
    etag: '"8cb7-6549c17c6f6b7;21a-5ab7fbc79d6f6' as const,
  }),

  /**
   * SHA-256 hex digest of the UTF-8 bytes of the HTML exactly as received.
   * Computed: 2026-08-03
   */
  sourceDigest:
    "71211579e01eeb9f7f6be9e01c9c2279f8fc0be84883cb1a94af7088723e34de" as const,

  /**
   * SHA-256 hex digest of the normalised text (BOM stripped, CRLF → LF,
   * trimmed). For this fixture the value equals sourceDigest because the
   * document contained no BOM and only LF line endings.
   *
   * Note: downstream HTML normalisation (strip tags → plain text) is a
   * separate step performed by the normalisation stage; it produces a
   * different digest from this one.
   * Computed: 2026-08-03
   */
  normalisedTextDigest:
    "71211579e01eeb9f7f6be9e01c9c2279f8fc0be84883cb1a94af7088723e34de" as const,

  /** Complete verbatim HTML as received. */
  html: APACHE_HTTPD_AUTH_HTML,

  suggestedCorpusMetadata: Object.freeze({
    domain: "TECHNICAL" as const,
    documentType: "GUIDE" as const,
    difficulty: "MEDIUM" as const,
    language: "en" as const,
  }),
});
